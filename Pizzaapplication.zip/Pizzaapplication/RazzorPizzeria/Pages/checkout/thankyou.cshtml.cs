using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace RazzorPizzeria.Pages.checkout
{
    public class thankyouModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
