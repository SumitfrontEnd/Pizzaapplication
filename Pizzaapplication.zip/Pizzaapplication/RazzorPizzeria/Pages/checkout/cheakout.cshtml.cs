using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazzorPizzeria.Data;
using RazzorPizzeria.Models;

namespace RazzorPizzeria.Pages.checkout
{
    [BindProperties(SupportsGet = true)]

    public class cheakoutModel : PageModel
    {
        private readonly ApplicationDbContext  _context ;    
        public cheakoutModel(ApplicationDbContext context)
        {
            _context= context;  

        }
        public string PizzaName { get; set; }

        public float PizzaPrice { get; set; }
        public string ImageTitle { get; set; }

        public void OnGet()
        {
            if (string.IsNullOrWhiteSpace(PizzaName))
            {
                PizzaName = "Custom";

            }
            if(string.IsNullOrWhiteSpace(ImageTitle))
            {
                ImageTitle= "Create";
            }
            PizzaOrder pizzaOrder= new PizzaOrder();    
            pizzaOrder.PizzaName= PizzaName;    
            pizzaOrder.BasePrice= PizzaPrice;   
            _context.PizzaOrders.Add(pizzaOrder);
            _context.SaveChanges();
        }
    }
}
