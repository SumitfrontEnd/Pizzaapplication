using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazzorPizzeria.Models;
namespace RazzorPizzeria.Pages
{
    public class pizzasModel : PageModel
    {
        public List<PizzasModel> fakePizzasDB = new List<PizzasModel>()
        {
           new PizzasModel() { ImageTitle="Margerita",PizzaName="Margerita",BasePrice=2,TomatoSauce=true,Cheese=true,FinalPrice=14} ,
           new PizzasModel() { ImageTitle="MeatFeast",PizzaName="MeatFeast",BasePrice=2,TomatoSauce=true,Cheese=true,FinalPrice=4} ,
           new PizzasModel() { ImageTitle="Hawaiian",PizzaName="Hawaiian",BasePrice=2,TomatoSauce=true,Cheese=true,FinalPrice=6} ,
           new PizzasModel() { ImageTitle="Carbonara",PizzaName="Carbonara",BasePrice=2,TomatoSauce=true,Cheese=true,FinalPrice=12} ,
           new PizzasModel() { ImageTitle="MeatFeast",PizzaName="Meatfeast",BasePrice=2,TomatoSauce=true,Cheese=true,FinalPrice=7} ,
           new PizzasModel() { ImageTitle="Pepperoni",PizzaName="Pepperoni",BasePrice=2,TomatoSauce=true,Cheese=true,FinalPrice=5} ,
           new PizzasModel() { ImageTitle="Seafood",PizzaName="SeaFood",BasePrice=2,TomatoSauce=true,Cheese=true,FinalPrice=13} 

        };

        public void OnGet()
        {
        }
    }
}
