using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using RazzorPizzeria.Models;

namespace RazzorPizzeria.Pages.forms
{
    public class CustomPizzaModel : PageModel
    {
        [BindProperty]
        public PizzasModel Pizza { get; set; } 
        public float PizzaPrice { get; set; }   
        public void OnGet()
        {

        }
        public IActionResult OnPost()
        {
            PizzaPrice = Pizza.BasePrice;
            if (Pizza.TomatoSauce) PizzaPrice += 1;
            if (Pizza.Cheese) PizzaPrice += 1;
            if (Pizza.Mohsroom) PizzaPrice += 1;
            if (Pizza.Peperoni) PizzaPrice += 1;
            if (Pizza.Tuna) PizzaPrice += 1;
            if (Pizza.PineApple) PizzaPrice += 10;
            if (Pizza.Ham) PizzaPrice += 1;
            return RedirectToPage("/checkout/cheakout",new {Pizza.PizzaName,PizzaPrice });

        }
    }
}
